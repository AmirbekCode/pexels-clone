import Categories from "./Categories"

export default function Challenges() {
    return(
        <div className='Challenges'>
            <Categories/>
        </div>
    )
}