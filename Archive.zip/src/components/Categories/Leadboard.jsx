import Categories from "./Categories";

export default function Leadeboard() {
    return(
        <div className='Leadeboard'>
            <Categories/>
        </div>
    )
}