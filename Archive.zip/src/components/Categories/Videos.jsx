import Categories from "./Categories"

export default function Videos() {
    return(
        <div className='Videos'>
            <Categories/>
        </div>
    )
}